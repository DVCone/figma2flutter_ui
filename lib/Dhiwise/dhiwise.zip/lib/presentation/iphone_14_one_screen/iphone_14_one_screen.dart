import 'controller/iphone_14_one_controller.dart';
import 'package:application/core/app_export.dart';
import 'package:application/core/utils/validation_functions.dart';
import 'package:application/widgets/custom_button.dart';
import 'package:application/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';

class Iphone14OneScreen extends GetWidget<Iphone14OneController> {
  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: ColorConstant.purpleA200,
        body: Container(
          width: size.width,
          child: SingleChildScrollView(
            child: Form(
              key: _formKey,
              autovalidateMode: AutovalidateMode.onUserInteraction,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Padding(
                    padding: getPadding(
                      left: 26,
                      top: 199,
                      right: 26,
                    ),
                    child: Text(
                      "lbl_login".tr,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.left,
                      style: AppStyle.txtInterBold30,
                    ),
                  ),
                  Container(
                    width: double.infinity,
                    margin: getMargin(
                      left: 26,
                      top: 33,
                      right: 24,
                      bottom: 5,
                    ),
                    decoration: AppDecoration.fillWhiteA700.copyWith(
                      borderRadius: BorderRadiusStyle.roundedBorder10,
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        CustomTextFormField(
                          width: 262,
                          focusNode: FocusNode(),
                          controller: controller.groupTwoController,
                          hintText: "lbl_email".tr,
                          margin: getMargin(
                            left: 39,
                            top: 49,
                            right: 39,
                          ),
                          validator: (value) {
                            if (value == null ||
                                (!isValidEmail(value, isRequired: true))) {
                              return "Please enter valid email";
                            }
                            return null;
                          },
                        ),
                        CustomTextFormField(
                          width: 262,
                          focusNode: FocusNode(),
                          controller: controller.groupOneController,
                          hintText: "lbl_password".tr,
                          margin: getMargin(
                            left: 39,
                            top: 40,
                            right: 39,
                          ),
                          padding: TextFormFieldPadding.PaddingAll11,
                          textInputAction: TextInputAction.done,
                          validator: (value) {
                            if (value == null ||
                                (!isValidPassword(value, isRequired: true))) {
                              return "Please enter valid password";
                            }
                            return null;
                          },
                          isObscureText: true,
                        ),
                        CustomButton(
                          width: 135,
                          text: "lbl_login".tr,
                          margin: getMargin(
                            left: 39,
                            top: 40,
                            right: 39,
                            bottom: 5,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
