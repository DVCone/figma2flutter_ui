class Iphone14OneModel {}
