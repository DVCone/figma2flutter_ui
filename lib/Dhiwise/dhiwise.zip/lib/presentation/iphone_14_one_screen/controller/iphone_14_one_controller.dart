import '/core/app_export.dart';
import 'package:application/presentation/iphone_14_one_screen/models/iphone_14_one_model.dart';
import 'package:flutter/material.dart';

class Iphone14OneController extends GetxController {
  TextEditingController groupTwoController = TextEditingController();

  TextEditingController groupOneController = TextEditingController();

  Rx<Iphone14OneModel> iphone14OneModelObj = Iphone14OneModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
    groupTwoController.dispose();
    groupOneController.dispose();
  }
}
