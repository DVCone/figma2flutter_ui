final Map<String, String> enUs = {
  'msg_network_err': 'Network Error',
  'msg_something_went_wrong': 'Something Went Wrong!',
  "lbl_email": "Email",
  "lbl_login": "Login",
  "lbl_password": "Password"
};
