import 'package:flutter/material.dart';
import 'package:application/core/app_export.dart';

class AppStyle {
  static TextStyle txtInterBold30 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      30,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w700,
  );
}
